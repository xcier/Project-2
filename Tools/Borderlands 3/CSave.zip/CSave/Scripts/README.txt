CSave SaveGenerate scripts

Run them like this:
SaveToProto original.sav; SaveGenerate in.proto out.proto < script.script; ProtoToSave out.proto original.sav edited.sav

NAME					DESCRIPTION
resetAllChallenges.script		Set all challenges to "incomplete".
proceduralName.sh			Enter a filename or wildcard (ex: *.sav) for the first argument. Changes the player's name to the filename.
